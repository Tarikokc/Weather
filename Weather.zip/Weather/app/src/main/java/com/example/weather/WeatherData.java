package com.example.weather;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class WeatherData {
    @SerializedName("name")
    private String cityName;

    @SerializedName("weather")
    private List<WeatherDescription> weatherDescriptions;

    @SerializedName("main")
    private MainData mainData;
    @SerializedName("wind")
    private Wild windData;  // Utilisez la classe Wild pour représenter les données du vent
    @SerializedName("icon")

    private Icon iconData;

    public Icon getIconData(){return iconData;};

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }


    public List<WeatherDescription> getWeatherDescriptions() {
        return weatherDescriptions;
    }

    public MainData getMainData() {
        return mainData;
    }

    public Wild getWindData() {
        return windData;
    }

    public void setWindData(Wild windData) {
        this.windData = windData;
    }








}
