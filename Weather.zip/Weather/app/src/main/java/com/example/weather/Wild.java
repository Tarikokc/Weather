package com.example.weather;
import com.google.gson.annotations.SerializedName;

public class Wild {
    @SerializedName("speed")
    private String vitesseV;
    @SerializedName("deg")
    private String directionV;

    public String getVitesseV() {
        return vitesseV;
    }

    public void setVitesseV(String vitesseV) {
        this.vitesseV = vitesseV;
    }

    public String getDirectionV() {
        return directionV;
    }

    public void setDirectionV(String directionV) {
        this.directionV = directionV;
    }
}
