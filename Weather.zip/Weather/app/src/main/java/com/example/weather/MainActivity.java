package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.SearchView;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;





import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import retrofit2.Call;
import retrofit2.Callback; // Assurez-vous d'avoir cette importation
import retrofit2.Response;

import android.widget.CompoundButton;


public class MainActivity extends AppCompatActivity {

    private TextView city;
    private TextView temperature;

    private TextView temperatureMin;
    private TextView temperatureMax;
    private TextView description;

    private TextView vitesseV;

    private TextView directionV;

    private TextView pressionV;
    private TextView humiditeV;
    private ImageView iconV;
    private SearchView search;
    private OpenWeatherMapService openWeatherMapService;
    private String apiKey = "9172a8ad144484f004ee9f70bab329bb";

    private String thunder = "11d";
    private String drizzle = "09d";
    private String rain = "10d";
    private String snow = "13d";
    private String atmosphere = "50d";
    private String clear = "01d";

    private String clouds ="ded";

    private String currentUnit = "metric";

    private String farunit = "imperial";
    private SearchView searchView;
    private String currentCity;

    private String ville;


    private Switch unitSwitch;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        openWeatherMapService = ApiClient.APIco().create(OpenWeatherMapService.class);


        city = findViewById(R.id.cityname);
        temperature = findViewById(R.id.temperaturecity);
        description = findViewById(R.id.descriptioncity);
        vitesseV = findViewById(R.id.vitesseVent);
        directionV = findViewById(R.id.directionVent);
        pressionV = findViewById(R.id.pression);
        humiditeV = findViewById(R.id.humidite);
        iconV = findViewById(R.id.iconMeteo);
        temperatureMin = findViewById(R.id.tempmin);
        temperatureMax = findViewById(R.id.tempmax);
        unitSwitch = findViewById(R.id.switch1);





        Call<WeatherData> call = openWeatherMapService.getCurrentWeatherData("Paris", apiKey, "metric");
        call.enqueue(new Callback<WeatherData>() {
            @Override
            public void onResponse(Call<WeatherData> call, Response<WeatherData> response) {
                if (response.isSuccessful()) {
                    WeatherData weatherData = response.body();
                    updateUI(weatherData);
                } else {
                    ErrorApp();
                }
            }

            @Override
            public void onFailure(Call<WeatherData> call, Throwable t) {
                ErrorApp();
            }
        });

        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Call<WeatherData> newCall = openWeatherMapService.getCurrentWeatherData(query, apiKey, "metric");
                newCall.enqueue(new Callback<WeatherData>() {
                    @Override
                    public void onResponse(Call<WeatherData> call, Response<WeatherData> response) {
                        if (response.isSuccessful()) {
                            WeatherData weatherData = response.body();
                            updateUI(weatherData);
                        } else {
                            ErrorApp();
                        }
                    }

                    @Override
                    public void onFailure(Call<WeatherData> call, Throwable t) {
                        ErrorApp();
                    }
                });
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });




    }



    public interface OpenWeatherMapService {
        @GET("weather")
        Call<WeatherData> getCurrentWeatherData(@Query("q") String location, @Query("appid") String apiKey,@Query("units") String units );
    }

    private void updateUI(WeatherData weatherData) {
        Log.d("WeatherApp", "Updating UI with data: " + weatherData);

        if (weatherData != null) {
            TextView cityTextView = findViewById(R.id.cityname);
            TextView temperatureTextView = findViewById(R.id.temperaturecity);
            TextView temperatureMinTextView = findViewById(R.id.tempmin);
            TextView temperatureMaxTextView = findViewById(R.id.tempmax);
            TextView descriptionTextView = findViewById(R.id.descriptioncity);
            TextView vitesseTextView = findViewById(R.id.vitesseVent);
            TextView directionTextView = findViewById(R.id.directionVent);
            TextView pressionTextView = findViewById(R.id.pression);
            TextView humiditeTextView = findViewById(R.id.humidite);
            ImageView iconImageView = findViewById(R.id.iconMeteo);

            cityTextView.setText(weatherData.getCityName() != null ? weatherData.getCityName() : "N/A");

            if (weatherData.getMainData() != null) {
                String temperature = weatherData.getMainData().getTemperature();
                String temperatureMin = weatherData.getMainData().getTemperatureMin();
                String temperatureMax = weatherData.getMainData().getTemperatureMax();

                temperatureTextView.setText("Temperature: " + (temperature != null ? Math.round(Double.parseDouble(temperature)) + "°C" : "N/A"));
                temperatureMinTextView.setText("Temperature min: " + (temperatureMin != null ? Math.round(Double.parseDouble(temperatureMin)) + " °C" : "N/A"));
                temperatureMaxTextView.setText("Temperature max: " + (temperatureMax != null ? Math.round(Double.parseDouble(temperatureMax)) + " °C" : "N/A"));

            } else {
                temperatureTextView.setText("Temperature: N/A");
            }
            if (weatherData.getMainData()!= null){
                String pressionV = weatherData.getMainData().getPression();
                pressionTextView.setText("Pression : "+ (pressionV != null ? pressionV + " HPa" : "N/A"));
            }

            if(weatherData.getMainData()!=null){
                String humiditeV = weatherData.getMainData().getHumidite();
                humiditeTextView.setText("Humidité : "+ (humiditeV != null ? humiditeV + " %" : "N/A"));

            }

            if (weatherData.getWeatherDescriptions() != null && !weatherData.getWeatherDescriptions().isEmpty()) {
                String description = weatherData.getWeatherDescriptions().get(0).getWeatherDescription();
                descriptionTextView.setText("Description: " + (description != null ? description : "N/A"));
            } else {
                descriptionTextView.setText("Description: N/A");
            }
            if (weatherData.getWindData() != null) {
                String windSpeed = weatherData.getWindData().getVitesseV();
                vitesseTextView.setText("Vitesse du vent : " + (windSpeed != null ? windSpeed + " m/s" : "N/A"));
            } else {
                vitesseTextView.setText("Vitesse du vent : N/A");

            }if (weatherData.getWindData() != null) {
                String windDirection = weatherData.getWindData().getDirectionV();
                directionTextView.setText("Direction du vent : " + (windDirection != null ? windDirection + "°" : "N/A"));
            } else {
                directionTextView.setText("Direction du vent : N/A");
            }

            if (weatherData.getIconData() != null) {
                String meteoIcon = weatherData.getIconData().getIcon();
                String iconUrl = "https://openweathermap.org/img/wn/" + meteoIcon + "@2x.png";

                Picasso.get().load(iconUrl).into(iconImageView);

            } else {
                // Gérer le cas où l'objet IconData est nul
                Log.e("WeatherApp", "IconData is null");
                // Vous pouvez également définir une icône par défaut ici si nécessaire

                // ex: iconV.setImageResource(R.drawable.default_icon);
            }






        } else {
            Log.e("WeatherApp", "Weather data is null");
            // Gérer le cas où les données météorologiques sont nulles
        }
    }






    private void ErrorApp (){
        Toast.makeText(MainActivity.this,"Erreur lors du chargement des données",Toast.LENGTH_SHORT).show();
    }






}

