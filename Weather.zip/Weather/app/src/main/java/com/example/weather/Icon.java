package com.example.weather;

import com.google.gson.annotations.SerializedName;

public class Icon {

    @SerializedName("icon")
    private String icon;

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }


}
