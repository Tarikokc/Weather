package com.example.weather;

import java.util.HashMap;
import java.util.Map;

public class IconMapper {
    private static final Map<String, String> iconMap = new HashMap<>();

    static {
        iconMap.put("light rain", "10d");
        iconMap.put("moderate rain", "10d");
        iconMap.put("heavy intensity rain", "10d");
        iconMap.put("very heavy rain", "10d");
        iconMap.put("extreme rain", "10d");
        iconMap.put("freezing rain", "13d");
        iconMap.put("light intensity shower rain", "09d");
        iconMap.put("shower rain", "09d");
        iconMap.put("heavy intensity shower rain", "09d");
        iconMap.put("ragged shower rain", "09d");

        // Mapping pour les descriptions des nuages
        iconMap.put("few clouds: 11-25%", "02d");
        iconMap.put("few clouds: 11-25% (night)", "02n");
        iconMap.put("scattered clouds: 25-50%", "03d");
        iconMap.put("scattered clouds: 25-50% (night)", "03n");
        iconMap.put("broken clouds: 51-84%", "04d");
        iconMap.put("broken clouds: 51-84% (night)", "04n");
        iconMap.put("overcast clouds: 85-100%", "04d"); // Assurez-vous d'avoir le bon icône ici
        iconMap.put("overcast clouds: 85-100% (night)", "04n"); // Assurez-vous d'avoir le bon icône ici
    }

    public static String getIconForDescription(String description) {
        return iconMap.get(description);
    }
}
