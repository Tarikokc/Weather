package com.example.weather;

import com.google.gson.annotations.SerializedName;

public class MainData {
    @SerializedName("temp")
    private String temperature;

    @SerializedName("temp_min")
    private String temperatureMin;

    @SerializedName("temp_max")
    private String temperatureMax;

    @SerializedName("pressure")
    private String pression;

    @SerializedName("humidity")
    private String humidite;

    public String getPression() {
        return pression;
    }

    public void setPression(String pression) {
        this.pression = pression;
    }

    public String getHumidite() {
        return humidite;
    }

    public void setHumidite(String humidite) {
        this.humidite = humidite;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getTemperatureMin() {
        return temperatureMin;
    }

    public void setTemperatureMin(String temperatureMin) {
        this.temperatureMin = temperatureMin;
    }

    public String getTemperatureMax() {
        return temperatureMax;
    }

    public void setTemperatureMax(String temperatureMax) {
        this.temperatureMax = temperatureMax;
    }
}
