package com.example.weather;

import com.google.gson.annotations.SerializedName;

public class WeatherDescription {
    @SerializedName("description")
    private String weatherDescription;
    @SerializedName("id")
    private int id;
    @SerializedName("icon")
    private String icon;
    public String getWeatherDescription() {
        return weatherDescription;
    }
    public void setWeatherDescription(String weatherDescription) {
        this.weatherDescription = weatherDescription;
    }

    // ... les méthodes getters et setters
}
